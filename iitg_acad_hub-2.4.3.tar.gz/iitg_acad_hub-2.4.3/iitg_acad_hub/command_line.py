from project import mainProject


def main():
	mainProject()